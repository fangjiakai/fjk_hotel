package com.fjk.hotel.user.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by Administrator on 2018/4/4.
 */
public class MD5Util {
    private static final String[] KEYS = {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"} ;

    private static String byteToString(byte b){
        int k = b;
        if (k<0){
            k+=256 ;
        }
        String s1 = KEYS[k/16];
        String s2 = KEYS[k%16];
        return s1+s2 ;
    }

    private static String byteArrayToString(byte[] byteArray){
        StringBuilder stringBuilder = new StringBuilder() ;
        for (byte b:byteArray){
            stringBuilder.append(byteToString(b)) ;
        }
        return stringBuilder.toString();
    }

    public static String md5(String password){
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5") ;
            byte[] byteArray = messageDigest.digest(password.getBytes()) ;
            return byteArrayToString(byteArray) ;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null ;
    }
}
