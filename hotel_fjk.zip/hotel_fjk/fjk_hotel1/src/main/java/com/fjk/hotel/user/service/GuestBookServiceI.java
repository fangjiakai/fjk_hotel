package com.fjk.hotel.user.service;

import com.fjk.hotel.user.po.GuestBook;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * Created by Administrator on 2018/4/16.
 */
public interface GuestBookServiceI {
    PageInfo selectAllMessage(Integer pageNo,Integer pageSize);

    int insertMessage(GuestBook guestBook);
}
