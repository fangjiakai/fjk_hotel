package com.fjk.hotel.order.service.impl;

import com.fjk.hotel.order.mapper.CateGoryMapper;
import com.fjk.hotel.order.mapper.GuestRoomMapper;
import com.fjk.hotel.order.po.CateGory;
import com.fjk.hotel.order.po.CateGoryExample;
import com.fjk.hotel.order.po.GuestRoom;
import com.fjk.hotel.order.po.GuestRoomExample;
import com.fjk.hotel.order.service.GuestRoomServiceI;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2018/1/11.
 */
@Service
@Transactional
public class GuestRoomServiceImpl implements GuestRoomServiceI {
    @Autowired
    private GuestRoomMapper guestRoomMapper;
    @Autowired
    private CateGoryMapper cateGoryMapper;
    //查找所有客房信息
    public PageInfo selectAllRoom(CateGoryExample cateGoryExample, int pageNo, int pageSize) {
        PageHelper.startPage(pageNo,pageSize);
        List<CateGory> list = cateGoryMapper.selectAllGuestRoom(cateGoryExample);
        PageInfo page = new PageInfo(list);
        return page;
    }

    //查找客房类型
    public List<CateGory> selectCategoryName() {
        CateGoryExample cateGoryExample = new CateGoryExample();
        return cateGoryMapper.selectByExample(cateGoryExample);
    }

    //根据id查找客房信息
    public CateGory selectRoomById(Integer id) {

        return cateGoryMapper.selectRoomById(id);
    }
    //查找客房状态
    public List<String> selectRoomStatus() {
        return guestRoomMapper.selectRoomStatus();
    }

    //通过id修改客房信息
    public int updateRoomById(GuestRoom guestRoom){
        return guestRoomMapper.updateByPrimaryKeyWithBLOBs(guestRoom);
    }

    public int addRoom(GuestRoom guestRoom) {

        return guestRoomMapper.insert(guestRoom);
    }

    //查找可预订客房
    public PageInfo selectAllBookingRoom(GuestRoomExample guestRoomExample, int pageNo, int pageSize) {
        PageHelper.startPage(pageNo,pageSize);
        List<GuestRoom> guestRoomList = guestRoomMapper.selectByExampleWithBLOBs(guestRoomExample);
        return new PageInfo(guestRoomList);
    }

    public int updateRoomStatusById(Long guestroomId) {
        String status = "";
        GuestRoom guestRoom = guestRoomMapper.selectByPrimaryKey(guestroomId);
        System.out.println(guestRoom.getGuestroomStatus());
        if(guestRoom.getGuestroomStatus().equals("可预订")){
            return guestRoomMapper.updateRoomStatus(guestroomId);
        }else{
            return guestRoomMapper.updateRoomStatusTwo(guestroomId);
        }
    }

    public List<CateGory> selectAllBookingRoomToFore() {
        List<CateGory> cateGoryList = cateGoryMapper.selectAllBookingRoom();
        return cateGoryList;
    }

    public String selectCateNameByRoomId(Long guestroomId) {

        return cateGoryMapper.selectCateNameById(guestroomId);
    }

    public GuestRoom selectBookingRoomById(Long guestroomId) {
        GuestRoom guestRoom = guestRoomMapper.selectByPrimaryKey(guestroomId);
        return guestRoom;
    }


}
