package com.fjk.hotel.user.credentials;

import com.fjk.hotel.user.encrypt.PasswordEncrypt;
import org.apache.log4j.Logger;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.credential.SimpleCredentialsMatcher;

/**
 * Created by Administrator on 2018/4/4.
 * 通过Credentials 和 CredentialsMatcher告诉shiro怎么加密和密码校验
 */
public class CustomerCredentialsMatcher extends SimpleCredentialsMatcher {
    private static final Logger log = Logger.getLogger(CustomerCredentialsMatcher.class) ;

    @Override
    public boolean doCredentialsMatch(AuthenticationToken token, AuthenticationInfo info) {
        //获得用户登录密码 进行加密
        Object tokenCredentials = PasswordEncrypt.encryptPassword(super.toString(token.getCredentials())).getBytes();
        Object accountCredentials = super.getCredentials(info) ;
        return super.equals(tokenCredentials,accountCredentials);
    }
}
