package com.fjk.hotel.order.controller;

import com.fjk.hotel.order.po.*;
import com.fjk.hotel.order.service.GuestRoomServiceI;
import com.fjk.hotel.order.service.OrderServiceI;
import com.github.pagehelper.PageInfo;
import com.sun.org.apache.xpath.internal.operations.Mod;
import net.sf.jsqlparser.expression.DateTimeLiteralExpression;
import org.apache.log4j.DailyRollingFileAppender;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2018/1/11.
 */
@Controller
@RequestMapping("/guestroom")
public class GuestRoomController {
    @Autowired
    private GuestRoomServiceI guestRoomServiceI;
    @Autowired
    private OrderServiceI orderServiceI;
    @Value("${MANAGE_DEFAULT_PAGE_SIZE}")
    private Integer MANAGE_DEFAULT_PAGE_SIZE;
    @Value("${GUESTROOM_IMAGE_PATH}")
    private String GUESTROOM_IMAGE_PATH;

    //日期绑定格式 没有就会报400错误
    @InitBinder
    public void initBinder(WebDataBinder binder) throws Exception {
        binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
    }

    /*获取所有客房信息*/
    @GetMapping
    @RequiresPermissions("manageroom")
    public ModelAndView queryAllRoom(@RequestParam(required = false)Double beginPrice,
                                     @RequestParam(required = false)Double endPrice,
                                     @RequestParam(required = false)Long category,
                                     @RequestParam(required = false) String field,
                                     @RequestParam(defaultValue = "1")Integer currentPage,
                                     @RequestParam(required = false)Integer pageSize) throws UnsupportedEncodingException {
        CateGoryExample cateGoryExample = new CateGoryExample();

        CateGoryExample.Criteria cateGoryCriteria1 = cateGoryExample.createCriteria();
        if(beginPrice!=null && endPrice!=null){
            cateGoryCriteria1.andGuestroomPriceBetween(beginPrice,endPrice);
        }
        System.out.println(category);
        if(category!=null){
            cateGoryExample.setCategoryId(category);
        }
        if(pageSize==null){
            pageSize = MANAGE_DEFAULT_PAGE_SIZE;
        }
        ModelAndView md = new ModelAndView();
        md.addObject("categoryList",guestRoomServiceI.selectCategoryName());
        md.addObject("page",guestRoomServiceI.selectAllRoom(cateGoryExample,currentPage,pageSize));
        md.addObject("beginPrice",beginPrice);
        md.addObject("endPrice",endPrice);
        md.addObject("category",category);
        md.addObject("field",field);
        md.setViewName("/backgroundmanage/guestroom-table.jsp");
        return md;
    }

    //通过id获取客房信息
    @RequestMapping(value="selectById",method = RequestMethod.GET)
    @RequiresPermissions("manageroom")
        public ModelAndView queryRoomById(@RequestParam(required = true) Integer guestroomId) throws UnsupportedEncodingException {
            ModelAndView md = new ModelAndView();
            md.addObject("roomStatus",guestRoomServiceI.selectRoomStatus());
            md.addObject("categoryList",guestRoomServiceI.selectCategoryName());
            md.addObject("category",guestRoomServiceI.selectRoomById(guestroomId));
            md.setViewName("/backgroundmanage/guestroom-detail.jsp");
        return md;
    }

    //通过id修改客房信息
    @RequestMapping(value ="updateRoomById",method = RequestMethod.PUT)
    @RequiresPermissions("manageroom")
    public String updateGuestroomById(@RequestParam Long roomId,
                                      @RequestParam Long roomCateGory,
                                      @RequestParam String roomsize,
                                      @RequestParam String roomDescb,
                                      @RequestParam String roomStatus,
                                      @RequestParam("roomPic") MultipartFile roomPic,HttpServletRequest request){
        String tomcatPath = request.getServletContext().getRealPath("");
        System.out.println(tomcatPath);
        File targetFile = new File(tomcatPath + GUESTROOM_IMAGE_PATH, roomPic.getOriginalFilename());
        if (!targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }
        try{
        roomPic.transferTo(targetFile);
        GuestRoom guestRoom = new GuestRoom();
        guestRoom.setGuestroomId(roomId);
        guestRoom.setCategoryId(roomCateGory);
        guestRoom.setGuestroomSize(roomsize);
        guestRoom.setDescb(roomDescb);
        guestRoom.setGuestroomStatus(roomStatus);
        guestRoom.setGuestroomPicture(GUESTROOM_IMAGE_PATH + roomPic.getOriginalFilename());
        guestRoomServiceI.updateRoomById(guestRoom);
        return "redirect:/guestroom.do";
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    //添加客房
    @RequestMapping(value ="addRoom",method = RequestMethod.POST)
    @RequiresPermissions("manageroom")
    public String addGuestroom(@RequestParam Long roomCateGory,
                               @RequestParam String roomSize,
                               @RequestParam String roomDescb,
                               @RequestParam("roomPic") MultipartFile roomPic,HttpServletRequest request) {
        System.out.println("===="+roomSize);
        String tomcatPath = request.getServletContext().getRealPath("");
        File targetFile = new File(tomcatPath + GUESTROOM_IMAGE_PATH, roomPic.getOriginalFilename());
        if (!targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }
        try {
            roomPic.transferTo(targetFile);
            GuestRoom guestRoom = new GuestRoom();
            guestRoom.setCategoryId(roomCateGory);
            guestRoom.setGuestroomSize(roomSize);
            guestRoom.setDescb(roomDescb);
            guestRoom.setGuestroomStatus("可预订");
            guestRoom.setGuestroomPicture(GUESTROOM_IMAGE_PATH + roomPic.getOriginalFilename());
            guestRoomServiceI.addRoom(guestRoom);
            return "redirect:/guestroom.do";
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;

    }

    //获取所有可预订客房给前台
    @RequestMapping(value = "getAllRoom",method = RequestMethod.GET)
    @ResponseBody
    public List<CateGory> getAllRoomToFore(){
        List<CateGory> guestRoomList = guestRoomServiceI.selectAllBookingRoomToFore();
        System.out.println(guestRoomList);
        return guestRoomList;
    }

    @RequestMapping(value = "getBookingRoomById",method = RequestMethod.GET)
    @RequiresPermissions("reserve")
    public ModelAndView toBookingPage(@RequestParam Integer roomId){
        ModelAndView md = new ModelAndView();
        guestRoomServiceI.updateRoomStatusById(roomId.longValue());
        md.addObject("guestroom",guestRoomServiceI.selectBookingRoomById(roomId.longValue()));
        md.setViewName("/foreground/bookingRoom.jsp");
        return md;
    }

    @RequestMapping(value = "giveupBooking",method = RequestMethod.GET)
    @RequiresPermissions("reserve")
    public ModelAndView backToRoomList(@RequestParam Long guestroomId){
        ModelAndView md = new ModelAndView();
        guestRoomServiceI.updateRoomStatusById(guestroomId);
        md.setViewName("/foreground/guestroom-list.jsp");
        return md;
    }
    //订房
    @RequestMapping(value = "bookingGuestroom",method = RequestMethod.POST)
    @RequiresPermissions("reserve")
    public ModelAndView bookingRoom(@RequestParam Long guestroomId,
                                    @RequestParam Long userId,
                                    @RequestParam Date enterTime,
                                    @RequestParam Date outTime,
                                    @RequestParam Long guestNumber){
        Order order = new Order();
        order.setUserId(userId);
        order.setCreateTime(new Date());
        order.setUpdateTime(new Date());
        orderServiceI.insertOrder(order);
        Order order1 = orderServiceI.selectByUserId(userId);
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setCreateTime(new Date());
        orderDetail.setEnterTime(enterTime);
        orderDetail.setOutTime(outTime);
        orderDetail.setGuestroomId(guestroomId);
        orderDetail.setGuestroomNumber(1l);
        orderDetail.setUpdateTime(new Date());
        orderDetail.setUserNumber(guestNumber);
        orderDetail.setOrderId(order1.getOrderId());
        orderServiceI.insertDetail(orderDetail);
        ModelAndView md = new ModelAndView();
        md.setViewName("/foreground/bookingSuccess.jsp");
        return md;
    }

}
