package com.fjk.hotel.order.po;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * Created by Administrator on 2018/3/22.
 */
public class OrderDetailDto {
    private Long detailId;
    private Long orderId;
    private String userName;
    private String phone;
    private Long categoryId;
    private String categoryName;
    private Long guestroomId;
    private Long userNumber;
    private Long guestroomNumber;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date enterTime;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date outTime;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date createTime;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date updateTime;

    public Long getDetailId() {
        return detailId;
    }

    public void setDetailId(Long detailId) {
        this.detailId = detailId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Long getGuestroomId() {
        return guestroomId;
    }

    public void setGuestroomId(Long guestroomId) {
        this.guestroomId = guestroomId;
    }

    public Long getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(Long userNumber) {
        this.userNumber = userNumber;
    }

    public Long getGuestroomNumber() {
        return guestroomNumber;
    }

    public void setGuestroomNumber(Long guestroomNumber) {
        this.guestroomNumber = guestroomNumber;
    }

    public Date getEnterTime() {
        return enterTime;
    }

    public void setEnterTime(Date enterTime) {
        this.enterTime = enterTime;
    }

    public Date getOutTime() {
        return outTime;
    }

    public void setOutTime(Date outTime) {
        this.outTime = outTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "OrderDetailDto{" +
                "detailId=" + detailId +
                ", orderId=" + orderId +
                ", userName='" + userName + '\'' +
                ", phone='" + phone + '\'' +
                ", categoryId=" + categoryId +
                ", categoryName='" + categoryName + '\'' +
                ", userNumber=" + userNumber +
                ", guestroomNumber=" + guestroomNumber +
                ", enterTime=" + enterTime +
                ", outTime=" + outTime +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
