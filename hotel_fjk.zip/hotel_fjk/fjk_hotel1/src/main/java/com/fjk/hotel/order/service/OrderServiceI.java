package com.fjk.hotel.order.service;

import com.fjk.hotel.order.po.Order;
import com.fjk.hotel.order.po.OrderDetail;
import com.fjk.hotel.order.po.OrderDetailDto;
import com.fjk.hotel.order.po.OrderExample;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * Created by Administrator on 2018/3/22.
 */
public interface OrderServiceI {

    //查找所有订单
    public PageInfo selectAllOrder(Integer pageNo, Integer pageSize, OrderExample orderExample);

    //根据id查找订单详情
    public List<OrderDetailDto> selectOrderById(Long orderId);

    //
    public OrderDetailDto selectDetailById(Long detailId);

    public int removeDetailById(Long detailId);

    public int updateDetailById(OrderDetailDto orderDetailDto);

    public int insertDetail(OrderDetail orderDetail);

    int insertOrder(Order order);

    Order selectByUserId(Long userId);

    List<OrderDetail> selectDetailByOrderId(Long orderId);


}
