package com.fjk.hotel.user.service.impl;

import com.fjk.hotel.user.mapper.GuestBookMapper;
import com.fjk.hotel.user.po.GuestBook;
import com.fjk.hotel.user.service.GuestBookServiceI;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2018/4/16.
 */
@Service
@Transactional
public class GuestBookServiceImpl implements GuestBookServiceI {
    @Autowired
    private GuestBookMapper guestBookMapper;
    public PageInfo selectAllMessage(Integer pageNo,Integer pageSize) {
        PageHelper.startPage(pageNo,pageSize);
        List<GuestBook> guestBooks = guestBookMapper.selectAllMessage();
        return new PageInfo(guestBooks);
    }

    public int insertMessage(GuestBook guestBook) {

        return guestBookMapper.insertMessage(guestBook);
    }
}
