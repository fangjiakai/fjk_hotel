package com.fjk.hotel.user.encrypt;

import com.fjk.hotel.user.util.MD5Util;

/**
 * Created by Administrator on 2018/4/4.
 */
public class PasswordEncrypt {
    /**
     * 加盐
     */
    private static final String SALT="d3d3LmphdmExMDIud2FuaG8uY29t";

    /**
     * 加盐规则
     */
    public static String encryptPassword(String password){
        return MD5Util.md5(password+"{{"+SALT+"}}");
    }
}
