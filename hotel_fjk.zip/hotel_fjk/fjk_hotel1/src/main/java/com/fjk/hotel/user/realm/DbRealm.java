package com.fjk.hotel.user.realm;

import com.fjk.hotel.user.encrypt.PasswordEncrypt;
import com.fjk.hotel.user.po.User;
import com.fjk.hotel.user.service.SysUserServiceI;
import org.apache.log4j.Logger;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Administrator on 2018/1/24.
 */
@Component
/*Realm的作用就是提供给shiro和数据库进行交互的一个中间层*/
public class DbRealm extends AuthorizingRealm {
    /*日志*/
    private static final Logger log = Logger.getLogger(DbRealm.class) ;
    @Autowired
    private SysUserServiceI sysUserServiceI;

    public void setSysUserService(SysUserServiceI sysUserServiceI){
        this.sysUserServiceI=sysUserServiceI;
    }

    /*授权*/
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        /*获得登录用户名*/
       String userName = (String) principalCollection.getPrimaryPrincipal();
        Map<String,Set<String>> map = sysUserServiceI.authorized(userName);
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        info.addRoles(map.get("roles"));
        info.addStringPermissions(map.get("perms"));
        return info;
    }

    /*认证*/
    protected AuthenticationInfo doGetAuthenticationInfo(
            AuthenticationToken authenticationToken) throws AuthenticationException {
        String userName = (String) authenticationToken.getPrincipal();
        String password = new String((char[]) authenticationToken.getCredentials());
        //密码使用加盐处理
        password = PasswordEncrypt.encryptPassword(password);
        log.debug("-----token--用户名【"+userName+"】----密码:【"+password+"】-------");
        List<User> userList = sysUserServiceI.certification(userName);
        if(userList.size()==0){
            log.warn("用户名【"+userName+"】不存在");
            throw new UnknownAccountException("用户名【"+userName+"】不存在");
        }
        if(!userList.get(0).getPassword().equals(password)){
            log.warn("用户名【"+userName+"】的密码【"+password+"】错误");
            throw new AuthenticationException("用户名【"+userName+"】的密码【"+password+"】错误");
        }
        return new SimpleAuthenticationInfo(userName,password,this.getName());
    }
}
