package com.fjk.hotel.user.service;

import com.fjk.hotel.user.po.User;
import com.fjk.hotel.user.po.UserStatus;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * Created by Administrator on 2018/1/11.
 */

public interface UserServiceI {
    /*通过id查找用户*/
    User selectUserById(Long id);

    User login(String name, String password);
    /*查找顾客资料*/
    PageInfo selectCustomer(User user, int pageNo, int pageSize);
    /*通过id查找顾客资料*/
    User selectById(Long userId);
    /*分页查找前台员工*/
    PageInfo selectEmp(User user, int pageNo, int pageSize);
    /*查找所有员工在职状态*/
    List<UserStatus> selectUserStatus();
    /*通过id查找前台员工*/
    User selectEmpById(Long userId);
    /*通过id更新资料*/
    int updateEmpById(User user);
    /*插入员工*/
    int insertEmp(User user);
    /*查看用户名是否已存在*/
    List<User> queryUserByName(String userName);
    /*通过id更新员工状态*/
    int updateEmpStatusById(User user);

    PageInfo getAllMessage(int pageNo,int pageSize);

}
