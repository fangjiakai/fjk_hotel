package com.fjk.hotel.user.service;

import com.fjk.hotel.user.po.User;
import com.fjk.hotel.user.po.UserRole;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Administrator on 2018/1/24.
 */
public interface SysUserServiceI {
    /*认证(通过用户名获得主体信息)*/
    List<User> certification(String userName);

    /*授权（根据用户名 获得该用户对应的角色名，对应的权限名）*/

    Map<String,Set<String>> authorized(String userName);

    //往用户表中插入信息
    int insertUser(User user);

    //通过用户名查找主键
    User selectIdByUsername(String username);

    //往用户角色表中插入信息
    int insertUserRole(UserRole userRole);

    void logoutUser();
}
