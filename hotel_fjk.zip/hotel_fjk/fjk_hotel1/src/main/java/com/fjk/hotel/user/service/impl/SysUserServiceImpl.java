package com.fjk.hotel.user.service.impl;

import com.fjk.hotel.user.mapper.UserMapper;
import com.fjk.hotel.user.mapper.UserRoleMapper;
import com.fjk.hotel.user.po.User;
import com.fjk.hotel.user.po.UserExample;
import com.fjk.hotel.user.po.UserRole;
import com.fjk.hotel.user.service.SysUserServiceI;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Administrator on 2018/1/24.
 */
@Service
@Transactional
public class SysUserServiceImpl implements SysUserServiceI {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private UserRoleMapper userRoleMapper;
    /*
      * @param userName  用户名
     * @return  null 账号不存在 或密码错误
     * */
    public  List<User> certification(String userName) {
        UserExample userExample = new UserExample();
        userExample.createCriteria().andUserNameEqualTo(userName);
       List<User> userList = userMapper.selectByExample(userExample);
        return userList;
    }

    /**
     * 根据用户名 获得 用户授权的方法
     * @param userName 根据用户名 获得该用户对应的角色名，对应的权限名
     * @return
     * <ul>
     *     <li>key:roles   value:角色名Set集</li>
     *     <li>key:perms   value:权限名Set集</li>
     * </ul>
     */
    public Map<String, Set<String>> authorized(String userName) {
        Map<String,Set<String>> map = new HashMap<String, Set<String>>(2);
        map.put("roles",userMapper.selectRoleNameSetByUserName(userName));
        map.put("perms",userMapper.selectPermNameSetByUserName(userName));
        return map;
    }

    //注册
    public int insertUser(User user) {

        return userMapper.insert(user);
    }

    public User selectIdByUsername(String username) {
        UserExample userExample = new UserExample();
        UserExample.Criteria criteria = userExample.createCriteria();
        criteria.andUserNameEqualTo(username);
        List<User> users = userMapper.selectByExample(userExample);
        return users.get(0);
    }

    public int insertUserRole(UserRole userRole) {

        return userRoleMapper.insert(userRole);
    }

    public void logoutUser() {
       Subject subject = SecurityUtils.getSubject();
       if(subject.isAuthenticated()){
           subject.logout();
       }
    }


}
