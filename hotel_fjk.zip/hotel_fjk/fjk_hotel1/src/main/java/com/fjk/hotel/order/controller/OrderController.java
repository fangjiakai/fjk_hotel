package com.fjk.hotel.order.controller;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.fjk.hotel.order.po.*;
import com.fjk.hotel.order.service.GuestRoomServiceI;
import com.fjk.hotel.order.service.OrderServiceI;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageInfo;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2018/3/22.
 */
@Controller
@RequestMapping("/order")
public class OrderController {
    @Resource
    private OrderServiceI orderServiceI;
    @Autowired
    private GuestRoomServiceI guestRoomServiceI;
    @Value("${MANAGE_DEFAULT_PAGE_SIZE}")
    private Integer MANAGE_DEFAULT_PAGE_SIZE;

    //日期绑定格式
    @InitBinder
    public void initBinder(WebDataBinder binder) throws Exception {
        binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
    }
    //获取所有订单
    @GetMapping
    @ResponseBody
    @RequiresPermissions("manageorder")
    public PageInfo selectAllOrder(@RequestParam(required = false) Date beginCreateTime,
                                   @RequestParam(required = false) Date endCreateTime,
                                   @RequestParam(defaultValue = "1") Integer pageNo,
                                   @RequestParam(required = false) Integer pageSize){
        OrderExample orderExample = new OrderExample();
        OrderExample.Criteria orderExampleCriteria = orderExample.createCriteria();
        if(beginCreateTime!=null&&endCreateTime!=null){
            orderExampleCriteria.andCreateTimeBetween(beginCreateTime,endCreateTime);
        }
        if(pageSize==null) {
            pageSize = MANAGE_DEFAULT_PAGE_SIZE;
        }
        PageInfo pageInfo = orderServiceI.selectAllOrder(pageNo, pageSize, orderExample);
        return pageInfo;
    }

    //根据订单号查找订单详情
    @RequestMapping(value ="selectOrderById",method = RequestMethod.GET)
    @ResponseBody
    @RequiresPermissions("manageorder")
    public ModelAndView selectOrderById(@RequestParam(required = false) Long orderId){
        ModelAndView md = new ModelAndView();
        md.addObject("orderList",orderServiceI.selectOrderById(orderId));
        md.addObject("orderId",orderId);
        md.setViewName("/backgroundmanage/order-detail.jsp");
        return md;
    }

    //根据详情号查找详情
    @RequestMapping(value = "selectOrderDetailById",method = RequestMethod.GET)
    @RequiresPermissions("manageorder")
    public ModelAndView selectDetailById(@RequestParam Long detailId){
        ModelAndView md = new ModelAndView();
        md.addObject("categoryList",guestRoomServiceI.selectCategoryName());
        md.addObject("orderDetail",orderServiceI.selectDetailById(detailId));
        md.setViewName("/backgroundmanage/orderDetail-Modify.jsp");
        return md;
    }

    //根据订单号删除信息
    @RequestMapping(value = "removeDetailById",method = RequestMethod.DELETE)
    @ResponseBody
    @RequiresPermissions("manageorder")
    public String removeDetailById(@RequestParam Long detailId){
        int flag = orderServiceI.removeDetailById(detailId);
        JSONObject json = new JSONObject();
        json.put("flag",flag);
        return json.toJSONString();
    }

    //新增详情信息
    @RequestMapping(value = "addOrderDetail",method = RequestMethod.POST)
    @RequiresPermissions("manageorder")
    public String updateDetailById(
                                   @RequestParam Long roomId,
                                   @RequestParam Long guestNumber,
                                   @RequestParam Date enterTime,
                                   @RequestParam Date outTime,
                                   @RequestParam Long orderId
                                   ){
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setGuestroomId(roomId);
        orderDetail.setOrderId(orderId);
        orderDetail.setUserNumber(guestNumber);
        orderDetail.setEnterTime(enterTime);
        orderDetail.setOutTime(outTime);
        orderDetail.setGuestroomNumber(1l);
        orderDetail.setCreateTime(new Date());
        orderDetail.setUpdateTime(new Date());
        orderServiceI.insertDetail(orderDetail);
        guestRoomServiceI.updateRoomStatusById(roomId);
        return "redirect:/order/selectOrderById.do?orderId="+orderId;
    }

    //获取所有客房类别并跳转页面
    @RequestMapping(value = "getRoomCategory",method = RequestMethod.GET)
    @RequiresPermissions("manageorder")
    public ModelAndView getAllroomCategory(@RequestParam Long orderId){
           ModelAndView md = new ModelAndView();
        md.addObject("categoryList",guestRoomServiceI.selectCategoryName());
        md.addObject("orderId",orderId);
        md.setViewName("/backgroundmanage/orderDetail_add.jsp");
        return md;
    }

    //获取可预订客房
    @RequestMapping(value = "selectedBookingRoom",method = RequestMethod.GET)
    @ResponseBody
    @RequiresPermissions("manageorder")
    public PageInfo selectBookingGuestroom(@RequestParam Long roomCategory,
                                           @RequestParam(defaultValue = "1") Integer pageNo,
                                           @RequestParam(required = false) Integer pageSize){
        if(pageSize==null){
            pageSize=MANAGE_DEFAULT_PAGE_SIZE;
        }
        GuestRoomExample guestRoomExample = new GuestRoomExample();
        GuestRoomExample.Criteria criteria = guestRoomExample.createCriteria();
        criteria.andCategoryIdEqualTo(roomCategory);
        criteria.andguestroomStatusEqualTo("可预订");
        PageInfo pageInfo = guestRoomServiceI.selectAllBookingRoom(guestRoomExample, pageNo, pageSize);
        return pageInfo;
    }

    //通过客户号查询订单
    @RequestMapping(value = "getMyOrder",method = RequestMethod.GET)
    @RequiresPermissions("reserve")
    public ModelAndView selectMyOrderById(@RequestParam Long userId){
        Order order = orderServiceI.selectByUserId(userId);
        List<OrderDetail> orderDetails = orderServiceI.selectDetailByOrderId(order.getOrderId());
        ModelAndView md = new ModelAndView();
        md.addObject("orderDetail",orderDetails);
        md.addObject("order",order);
        md.setViewName("/foreground/myOrder.jsp");
        return md;
    }
}

