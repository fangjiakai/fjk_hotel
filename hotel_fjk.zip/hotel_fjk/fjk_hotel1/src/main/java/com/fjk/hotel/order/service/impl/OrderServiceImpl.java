package com.fjk.hotel.order.service.impl;

import com.fjk.hotel.order.mapper.OrderDetailMapper;
import com.fjk.hotel.order.mapper.OrderMapper;
import com.fjk.hotel.order.po.*;
import com.fjk.hotel.order.service.OrderServiceI;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by Administrator on 2018/3/22.
 */
@Service
@Transactional
public class OrderServiceImpl implements OrderServiceI {
    @Resource
    private OrderMapper orderMapper;
    @Resource
    private OrderDetailMapper orderDetailMapper;
    //查找所有订单
    public PageInfo selectAllOrder(Integer pageNo, Integer pageSize, OrderExample orderExample) {
        PageHelper.startPage(pageNo,pageSize);
        List<Order> orders = orderMapper.selectByExample(orderExample);
        System.out.println(orders);
        return new PageInfo(orders);
    }

    //根据id查找订单
    public List<OrderDetailDto> selectOrderById(Long orderId) {
        return orderDetailMapper.selectOrderDetailById(orderId);
    }

    //根据id查找订单详情
    public OrderDetailDto selectDetailById(Long detailId) {

        return orderDetailMapper.selectDetailByDetailId(detailId);
    }
    //根据id删除订单详情
    public int removeDetailById(Long detailId) {

        return orderDetailMapper.deleteByPrimaryKey(detailId);
    }
    //根据id修改订单详情
    public int updateDetailById(OrderDetailDto orderDetailDto) {

        return  orderDetailMapper.updateDetailById(orderDetailDto);
    }

    public int insertDetail(OrderDetail orderDetail) {

        return orderDetailMapper.insert(orderDetail);
    }

    public int insertOrder(Order order) {

        return orderMapper.insert(order);
    }

    public Order selectByUserId(Long userId) {
        OrderExample orderExample = new OrderExample();
        OrderExample.Criteria criteria = orderExample.createCriteria();
        criteria.andUserIdEqualTo(userId);
        List<Order> orders = orderMapper.selectByExample(orderExample);
        return orders.get(0);
    }

    public List<OrderDetail> selectDetailByOrderId(Long orderId) {
        List<OrderDetail> orderDetails = orderDetailMapper.selectDetailByOrderId(orderId);
        return  orderDetailMapper.selectDetailByOrderId(orderId);
    }


}
