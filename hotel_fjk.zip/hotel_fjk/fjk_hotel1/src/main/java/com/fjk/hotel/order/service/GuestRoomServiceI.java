package com.fjk.hotel.order.service;

import com.fjk.hotel.order.po.CateGory;
import com.fjk.hotel.order.po.CateGoryExample;
import com.fjk.hotel.order.po.GuestRoom;
import com.fjk.hotel.order.po.GuestRoomExample;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * Created by Administrator on 2018/1/11.
 */
public interface GuestRoomServiceI {
    //查找所有客房
    PageInfo selectAllRoom(CateGoryExample cateGoryExample, int pageNo, int pageSize);
    //查找客房类型
    List<CateGory> selectCategoryName();
    //根据id查找客房信息
    CateGory selectRoomById(Integer id);
    //查找所有客房状态
    List<String> selectRoomStatus();
    //通过id修改客房信息
    int updateRoomById(GuestRoom guestRoom);
    //添加客房
    int addRoom(GuestRoom guestRoom);

    //查找可预订房间
    PageInfo selectAllBookingRoom(GuestRoomExample guestRoomExample,int pageNo,int pageSize);
    //根据id修改客房状态
    int updateRoomStatusById(Long guestroomId);

    List<CateGory> selectAllBookingRoomToFore();

    String selectCateNameByRoomId(Long guestroomId);

    GuestRoom selectBookingRoomById(Long guestroomId);


}
