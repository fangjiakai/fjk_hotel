package com.fjk.hotel.user.filter;

import com.fjk.hotel.user.mapper.UserMapper;
import com.fjk.hotel.user.po.User;
import com.fjk.hotel.user.po.UserExample;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;
import org.apache.shiro.web.filter.mgt.DefaultFilter;
import org.apache.shiro.web.util.WebUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.List;

import static org.apache.shiro.web.filter.mgt.DefaultFilter.user;

/**
 * Created by Administrator on 2018/4/8.
 */
public class CustomerFormAuthenticationFilter extends FormAuthenticationFilter {
    @Autowired
    private UserMapper userMapper;

    @Override
    protected boolean onLoginSuccess(AuthenticationToken token, Subject subject, ServletRequest request, ServletResponse response) throws Exception {
        String username= (String)subject.getPrincipal();
        UserExample userExample = new UserExample();
        UserExample.Criteria criteria = userExample.createCriteria();
        criteria.andUserNameEqualTo(username);
        //获取session
        HttpServletRequest httpServletRequest = WebUtils.toHttp(request);
        HttpSession session = httpServletRequest.getSession();
        List<User> users = userMapper.selectByExample(userExample);
        //把用户信息保存到session
        session.setAttribute("user", users.get(0));
        return super.onLoginSuccess(token, subject, request, response);
    }
}
