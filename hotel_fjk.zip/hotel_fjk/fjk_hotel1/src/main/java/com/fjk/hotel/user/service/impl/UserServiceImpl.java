package com.fjk.hotel.user.service.impl;

import com.fjk.hotel.user.mapper.UserMapper;
import com.fjk.hotel.user.mapper.UserStatusMapper;
import com.fjk.hotel.user.po.User;
import com.fjk.hotel.user.po.UserExample;
import com.fjk.hotel.user.po.UserStatus;
import com.fjk.hotel.user.po.UserStatusExample;
import com.fjk.hotel.user.service.UserServiceI;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2018/1/12.
 */
@Service
@Transactional
public class UserServiceImpl implements UserServiceI {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private UserStatusMapper userStatusMapper;

    public User selectUserById(Long id) {
        User user = userMapper.selectByPrimaryKey(id);
        return user;
    }

    public User login(String name, String password) {
        UserExample userExample = new UserExample();
        UserExample.Criteria criteria = userExample.createCriteria();
        if(password!=null) {
            criteria.andPasswordEqualTo("password");
        }
        if(name!=null) {
            criteria.andUserNameEqualTo("name");
        }
        List<User> list = userMapper.selectByExample(userExample);
        return list.get(0);
    }

    public PageInfo selectCustomer(User user,int pageNo,int pageSize) {
        PageHelper.startPage(pageNo,pageSize);
        List<User> userList = userMapper.selectCustomer(user);
        return new PageInfo(userList);
    }

    public User selectById(Long userId) {
       User user = userMapper.selectByPrimaryKey(userId);
        return user;
    }

    public PageInfo selectEmp(User user, int pageNo, int pageSize) {

        PageHelper.startPage(pageNo,pageSize);
        List<User> userList = userMapper.selectEmp(user);
        return new PageInfo(userList);
    }
    public List<UserStatus> selectUserStatus(){
        UserStatusExample userStatusExample = new UserStatusExample();
        List<UserStatus> userStatusList = userStatusMapper.selectByExample(userStatusExample);
        return userStatusList;
    }

    public User selectEmpById(Long userId) {
        User emp = userMapper.selectEmpById(userId);
        return emp;
    }

    public int updateEmpById(User user) {
        return userMapper.updateByPrimaryKey(user);
    }

    public int insertEmp(User user) {

        return  userMapper.insert(user);
    }

    public List<User> queryUserByName(String userName) {
        UserExample userExample = new UserExample();
        userExample.createCriteria().andUserNameEqualTo(userName);
        List<User> userList = userMapper.selectByExample(userExample);
        return userList;
    }

    public int updateEmpStatusById(User user) {
        return  userMapper.updateEmpStatusById(user);
    }

    public PageInfo getAllMessage(int pageNo, int pageSize) {
        PageHelper.startPage(pageNo,pageSize);
        List<User> users = userMapper.selectAllMessage();
        return new PageInfo(users);
    }



}
