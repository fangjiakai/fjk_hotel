package com.fjk.hotel.user.mapper;

import com.fjk.hotel.user.po.GuestBook;

import java.util.List;

/**
 * Created by Administrator on 2018/4/13.
 */
public interface GuestBookMapper {

    List<GuestBook> selectAllMessage();

    int insertMessage(GuestBook guestBook);
}
