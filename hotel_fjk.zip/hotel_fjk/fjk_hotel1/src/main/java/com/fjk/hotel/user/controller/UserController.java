package com.fjk.hotel.user.controller;

import com.alibaba.fastjson.JSONObject;
import com.fjk.hotel.user.encrypt.PasswordEncrypt;
import com.fjk.hotel.user.po.GuestBook;
import com.fjk.hotel.user.po.User;
import com.fjk.hotel.user.po.UserRole;
import com.fjk.hotel.user.po.UserStatus;
import com.fjk.hotel.user.service.GuestBookServiceI;
import com.fjk.hotel.user.service.SysUserServiceI;
import com.fjk.hotel.user.service.UserServiceI;
import com.fjk.hotel.user.util.MD5Util;
import com.github.pagehelper.PageInfo;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2018/1/12.
 */
@Controller
@RequestMapping("/user")
public class UserController {
   @Autowired
    private UserServiceI userServiceI;
    @Autowired
    private SysUserServiceI sysUserServiceI;
    @Autowired
    private GuestBookServiceI guestBookServiceI;

   //日期格式
    @InitBinder
    public void initBinder(WebDataBinder binder) throws Exception {
        binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
    }

    //加盐
    private static final String SALT="d3d3LmphdmExMDIud2FuaG8uY29t";

   @Value("${MANAGE_DEFAULT_PAGE_SIZE}")
   private Integer MANAGE_DEFAULT_PAGE_SIZE;
   //获取客户资料
   @GetMapping
   @RequiresPermissions("managecustomer")
   public ModelAndView queryCustomer(@RequestParam(required = false)String userName, @RequestParam(defaultValue = "1")Integer currentPage,
                                     @RequestParam(required = false) Integer pageSize) throws UnsupportedEncodingException {
       ModelAndView md = new ModelAndView();
       if(pageSize==null){
           pageSize=MANAGE_DEFAULT_PAGE_SIZE;
       }
       if(userName!=null) {
           userName = new String(userName.getBytes("iso-8859-1"), "UTF-8");
       }
       User user = new User();
       user.setUserName(userName);
       md.addObject("page",userServiceI.selectCustomer(user,currentPage,pageSize));
       md.addObject("cus",user);
       md.setViewName("/backgroundmanage/customer-table.jsp");
       return md;
   }
    //通过id查找资料
   @RequestMapping(value = "selectById",method = RequestMethod.GET)
   @RequiresPermissions("managecustomer")
    public ModelAndView queryById(Long userId){
        ModelAndView md = new ModelAndView();
        md.addObject("user",userServiceI.selectUserById(userId));
        md.setViewName("/backgroundmanage/cus-form.jsp");
        return md;
   }

   /*分页查找员工*/
   @RequestMapping(value = "selectEmp",method = RequestMethod.GET)
   @ResponseBody
   @RequiresPermissions("manageemp")
   public PageInfo queryEmp(
                            @RequestParam(required = false) String userName,
                            @RequestParam(required = false) String phone,
                            @RequestParam(required = false) Long statusId,
                            @RequestParam(required = false) Date beginCreateTime,
                            @RequestParam(required = false) Date endCreateTime,
                            @RequestParam(defaultValue = "1",required = false) Integer pageNo,
                            @RequestParam(required = false) Integer pageSize) throws UnsupportedEncodingException {

        User user = new User();
        if(pageSize==null){
            pageSize=MANAGE_DEFAULT_PAGE_SIZE;
        }
        if(userName!=null){
            userName = new String(userName.getBytes("iso-8859-1"), "UTF-8");
            user.setUserName(userName);
        }
        if(phone!=null){
            user.setPhone(phone);
        }
        if(statusId!=null){
            user.setStatusId(statusId);
        }
        if(beginCreateTime!=null&&endCreateTime!=null&&beginCreateTime.getTime()<=endCreateTime.getTime()){
            user.setBeginCreateTime(beginCreateTime);
            user.setEndCreateTime(endCreateTime);
        }
        return userServiceI.selectEmp(user,pageNo,pageSize);
   }

   //查找员工在职状态
   @RequestMapping(value = "selectStatus",method = RequestMethod.GET)
   @ResponseBody
   @RequiresPermissions("manageemp")
   public List<UserStatus> queryStatus(){
       return userServiceI.selectUserStatus();
   }

   //查找员工
   @RequestMapping(value = "selectEmpById",method = RequestMethod.GET)
   @RequiresPermissions("manageemp")
    public ModelAndView queryEmpById(@RequestParam(required = false)Long userId){
        ModelAndView md = new ModelAndView();
        md.addObject("emp",userServiceI.selectEmpById(userId));
        md.setViewName("/backgroundmanage/emp-form.jsp");
        return md;
   }

   //修改个人资料
    @RequestMapping(value = "updatePersonal",method = RequestMethod.PUT)
    public String updatePersonalById(@RequestParam Long userId,
                                     @RequestParam String username,
                                     @RequestParam String password,
                                     @RequestParam String userphone,
                                     @RequestParam Date createTime,
                                     @RequestParam Long statusId ){
        User user = new User();
        user.setUpdateTime(new Date());
        user.setCreateTime(createTime);
        user.setPhone(userphone);
        user.setPassword(password);
        user.setUserName(username);
        user.setUserId(userId);
        user.setStatusId(statusId);
        userServiceI.updateEmpById(user);
        return "/backgroundmanage/user-list.jsp";
    }

   //修改员工信息
   @RequestMapping(value = "updateEmpById",method = RequestMethod.PUT)
   @RequiresPermissions("manageemp")
   public String updateEmpById(@RequestParam Long userId,
                                @RequestParam String cusName,
                                @RequestParam String password,
                                @RequestParam String phone,
                                @RequestParam Long statusId,
                                @RequestParam Date createTime,
                                @RequestParam Date updateTime){
        User emp = new User();
        emp.setUserId(userId);
        emp.setUserName(cusName);
        emp.setPassword(password);
        emp.setPhone(phone);
        emp.setStatusId(statusId);
        emp.setCreateTime(createTime);
        emp.setUpdateTime(new Date());
       userServiceI.updateEmpById(emp);
       return "/backgroundmanage/emp-table.jsp";
   }

   //添加员工
   @RequestMapping(value = "addEmp",method = RequestMethod.POST)
   @RequiresPermissions("manageemp")
   public ModelAndView addEmp(@RequestParam String empName,
                          @RequestParam String password,
                          @RequestParam String phone){
        ModelAndView md = new ModelAndView();
       List<User> userList = userServiceI.queryUserByName(empName);
       System.out.println(userList);
       if (userList.size()>0){
           md.addObject("msg","用户名已存在");
       }else {
           User emp = new User();
           emp.setUserName(empName);
           emp.setPhone(phone);
           emp.setPassword(password);
           emp.setCreateTime(new Date());
           emp.setUpdateTime(new Date());
           emp.setStatusId(1l);
           userServiceI.insertEmp(emp);
       }
       User user = sysUserServiceI.selectIdByUsername(empName);
       UserRole userRole = new UserRole();
       userRole.setUserId(user.getUserId());
       userRole.setRoleId(2l);
       sysUserServiceI.insertUserRole(userRole);
       md.setViewName("/backgroundmanage/emp-table.jsp");
       return md;
   }

   //修改员工状态
    @RequestMapping(value = "updateEmpStatus",method = RequestMethod.PUT)
    @ResponseBody
    @RequiresPermissions("manageemp")
    public boolean updateEmpStatusById(@RequestParam Long userId,
                                      @RequestParam Long statusId){
        User user = new User();
        user.setUserId(userId);
        if(statusId==1l){
            user.setStatusId(2l);
        }else{
            user.setStatusId(1l);
        }
        int flag = userServiceI.updateEmpStatusById(user);
        return flag>0;
    }

    //用户注册
    @RequestMapping(value = "register",method = RequestMethod.POST)
    public ModelAndView register(@RequestParam String username,
                           @RequestParam String password,
                           @RequestParam String phone){
        User user = new User();
        user.setUserName(username);
        user.setPassword(MD5Util.md5(password+"{{"+SALT+"}}"));
        user.setPhone(phone);
        user.setCreateTime(new Date());
        user.setUpdateTime(new Date());
        sysUserServiceI.insertUser(user);
        User user1 = sysUserServiceI.selectIdByUsername(username);
        UserRole userRole = new UserRole();
        userRole.setUserId(user1.getUserId());
        userRole.setRoleId(2l);
        int i = sysUserServiceI.insertUserRole(userRole);
        ModelAndView md = new ModelAndView();
        if(i>0){
            md.addObject("msg","注册成功,请登录");
        }
        md.addObject("username",username);
        md.addObject("password",password);
        md.setViewName("/backgroundmanage/login.jsp");
        return md;
    }

    //检查重名
    @RequestMapping(value = "checkName",method = RequestMethod.POST)
    @ResponseBody
//    @RequiresPermissions("manageemp")
    public String checkUsername(@RequestParam String name){
        List<User> userList = userServiceI.queryUserByName(name);
        JSONObject jsonObject = new JSONObject();
        if(userList.size()>0){
            jsonObject.put("flag",userList.size());
        }
       return jsonObject.toJSONString();

    }

    //退出登录
    @RequestMapping(value = "userLogout")
    public ModelAndView userLogout(){
        ModelAndView md = new ModelAndView();
        sysUserServiceI.logoutUser();
        md.addObject("logmsg","用户已注销，请重新登录");
        md.setViewName("/backgroundmanage/login.jsp");
        return md;
    }

    @RequestMapping(value = "getAllMessage",method = RequestMethod.GET)
    @ResponseBody
    public PageInfo selectAllGuestBook(@RequestParam(defaultValue = "1") Integer pageNo,
                                       @RequestParam(required = false) Integer pageSize){

        if(pageSize==null){
            pageSize=MANAGE_DEFAULT_PAGE_SIZE;
        }
        return userServiceI.getAllMessage(pageNo,pageSize);
    }

    @RequestMapping(value = "addMessage",method = RequestMethod.POST)
    public String insertMessage(@RequestParam String msg,
                                @RequestParam Long userId){
        ModelAndView md = new ModelAndView();
        GuestBook guestBook = new GuestBook();
        guestBook.setUserId(userId);
        guestBook.setMessage(msg);
        guestBook.setCreateTime(new Date());
        guestBookServiceI.insertMessage(guestBook);
        return "/foreground/message.jsp";
    }

}
