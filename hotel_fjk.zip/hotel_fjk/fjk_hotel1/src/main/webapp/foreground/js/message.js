/**
 * Created by Administrator on 2018/4/16.
 */
$(function(){
    showPageList(1);
})

function showPageList(pageNo) {
    $.getJSON("/user/getAllMessage.do?pageNo="+pageNo,function(data){
        console.log(data.list.guestBookList);
        $("tbody").empty();
        $.each(data.list,function (index,ele) {
            $.each(ele.guestBookList,function(i,e){
            var trData='<tr>\
                        <td>'+ele.userName+'</td>\
                        <td>'+e.message+'</td>\
                        <td>'+formatDateTime(e.createTime)+'</td>\
                    </tr>';
            $("tbody").append(trData);
        })
        })
        showPageNav(data);
    })
}

function showPageNav(data){
    var $pageNav=$(".pagenavi");
    $pageNav.empty();
    // $pageNav.append('<li>共'+data.total+'条记录</li>');
    $pageNav.append('<a class="page" href="javascript:showPageList('+data.prePage+');">&lt;</a>');
    for(var i=1;i<=data.pages;i++){
        if(i==data.pageNum){
            $pageNav.append('<a class="page">'+i+'</a>');
        }else{
            $pageNav.append('<a class="page" href="javascript:showPageList('+i+')">'+i+'</a>')
        }
    }
$pageNav.append('<a class="page" href="javascript:showPageList('+data.nextPage+');">&gt;</a>');
}

function formatDateTime(inputTime) {
    var date = new Date(inputTime);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return y + '-' + m + '-' + d;
}