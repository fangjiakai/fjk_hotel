/**
 * Created by Administrator on 2018/4/11.
 */
$(function(){

    showPageList();
})

function showPageList() {
    $.getJSON("/guestroom/getAllRoom.do", function (data) {
        $("#guestList").empty();
        $.each(data, function (i,e) {
            $.each(e.guestRoomList,function(index,ele){
            console.log(ele.guestroomPicture);
                var roomUl = ' <li>\
                        <div class="ts-gallery-img">\
                        <a title="" data-rel="prettyPhoto[mixed]" href="' + ele.guestroomPicture + '" class="image">\
                        <span class="rollover"></span>\
                        <img class="scale-with-grid" alt="" src="' + ele.guestroomPicture + '" /></a>\
                        </div>\
                        <div class="ts-gallery-text ">\
                        <h2>'+e.categoryName+'</h2>\
                        <p>客房大小：'+ele.guestroomSize+' </p>\
                        <p>客房描述：'+ele.descb +'</p>\
                        <a href="#" class="button" onclick="toBooking('+ele.guestroomId+')">预定</a>\
                        </div>\
                        <div class="ts-gallery-clear"></div>\
                        </li>\
                </ul>';
                $("#guestList").append(roomUl);

            })
        })
})
}

function showPageNav(data){
    var $pageNav=$(".pager .clearfix");
    $pageNav.empty();
    $pageNav.append('<li>共查到'+data.total+'套房</li>');
    $pageNav.append('<li><a href="javascript:showPageList('+data.prePage+');">上一页</a></li>');
    for(var i=1;i<=data.pages;i++){
        if(i==data.pageNum){
            $pageNav.append('<li>'+i+'</li>');
        }else{
            $pageNav.append('<li><a href="javascript:showPageList('+i+')">'+i+'</a></li>')
        }
    }
    $pageNav.append('<li><a href="javascript:showPageList('+data.nextPage+');">下一页</a></li>');
}

function toBooking(roomId){
    location.href="/guestroom/getBookingRoomById.do?roomId="+roomId;
}