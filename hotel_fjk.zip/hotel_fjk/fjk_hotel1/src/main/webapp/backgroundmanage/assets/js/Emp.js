$(function(){
    searchBind();
    selectUserStatus();
    showPageList(1);
});
function selectUserStatus(){
    $.getJSON("/user/selectStatus.do",function(data){
        console.log(data);
       /* $("#hiddenSe1").append('');*/
        $.each(data,function(index,ele){
            $("#hiddenSe1").append('<option value='+ele.statusId+'>'+ele.status+'</option>');
        })
    })
}
function showPageList(pageNo){
    var userName = $("#hiddenIn1 input").val();
    console.log(userName);
    var phone = $("#hiddenIn3 input").val();
    var beginCreateTime = $("#hiddenIn2 input:eq(0)").val();
    var endCreateTime = $("#hiddenIn2 input:eq(1)").val();
    console.log(endCreateTime);
    var statusId = $("#hiddenSe1").val();
   // if(statusId==0){
   //     statusId="";
   // }

    $.getJSON("/user/selectEmp.do?userName="+userName+"&phone="+phone+"&beginCreateTime="+beginCreateTime+"&endCreateTime="+endCreateTime+"&pageNo="+pageNo+"&statusId="+statusId,function(data){
        $("tbody").empty();
        $.each(data.list,function(index,ele){
            if(ele.statusId==1){
                var trData = '<tr>\
            <td>'+ele.userId+'</td>\
            <td>'+ele.userName+'</td>\
            <td>'+ele.phone+'</td>\
            <td>'+ele.userStatus.status+'</td>\
            <td>'+formatDateTime(ele.createTime)+'</td>\
            <td>'+formatDateTime(ele.updateTime)+'</td>\
            <td>\
            <div class="am-btn-toolbar">\
                <div class="am-btn-group am-btn-group-xs">\
                <button class="am-btn am-btn-default am-btn-xs am-text-secondary" onclick="showEmpDetail('+ele.userId+')"><span class="am-icon-pencil-square-o"></span>查看/修改</button>\
                <button class="am-btn am-btn-default am-btn-xs am-text-danger" onclick="removeEmp('+ele.userId+','+ele.statusId+')"><span class="am-icon-trash-o"></span>离职</button>\
                </div>\
                </div>\
            </td>';
            }else{
            var trData = '<tr>\
            <td>'+ele.userId+'</td>\
            <td>'+ele.userName+'</td>\
            <td>'+ele.phone+'</td>\
            <td>'+ele.userStatus.status+'</td>\
            <td>'+formatDateTime(ele.createTime)+'</td>\
            <td>'+formatDateTime(ele.updateTime)+'</td>\
            <td>\
            <div class="am-btn-toolbar">\
                <div class="am-btn-group am-btn-group-xs">\
                <button class="am-btn am-btn-default am-btn-xs am-text-secondary" onclick="showEmpDetail('+ele.userId+')"><span class="am-icon-pencil-square-o"></span>查看/修改</button>\
                <button class="am-btn am-btn-default am-btn-xs am-text-danger" onclick="removeEmp('+ele.userId+','+ele.statusId+')"><span class="am-icon-trash-o"></span>在职</button>\
                </div>\
                </div>\
            </td>';
            }
            $("tbody").append(trData);

        });
        showPageNav(data);
    });
}

function showPageNav(data){
    var $pageNav=$(".pager .clearfix");
    $pageNav.empty();
    $pageNav.append('<li>共'+data.total+'条记录</li>');
    $pageNav.append('<li><a href="javascript:showPageList('+data.prePage+');">上一页</a></li>');
    for(var i=1;i<=data.pages;i++){
        if(i==data.pageNum){
        $pageNav.append('<li>'+i+'</li>');
        }else{
            $pageNav.append('<li><a href="javascript:showPageList('+i+')">'+i+'</a></li>')
        }
    }
    $pageNav.append('<li><a href="javascript:showPageList('+data.nextPage+');">下一页</a></li>');
}

function formatDateTime(inputTime) {
    var date = new Date(inputTime);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return y + '-' + m + '-' + d;
}

function showEmpDetail(userId){
    location.href="/user/selectEmpById.do?userId="+userId;
}

function removeEmp(userId,statusId){
    $.post("/user/updateEmpStatus.do",{
        "_method":"PUT",
        "userId":userId,
        "statusId":statusId
    },function(data){
        if(data){
            showPageList(1);
        }
    }
    );

}