/**
 * Created by Administrator on 2018/3/22.
 */
$(function(){

})
function showRoomModel(){
    $('#myModal').modal("show");
    var roomCategory =  $("#roomCateGory").val();
    showPageList(1,roomCategory);
}

function showPageList(pageNo,roomCategory){

    $.getJSON("/order/selectedBookingRoom.do?roomCategory="+roomCategory+"&pageNo="+pageNo,function(data) {
        console.log(data.list);
        $("thead").empty();
        var head = '<tr>\
            <th class="table-set"></th>\
            <th class="table-set">' + '客房编号' + '</th>\
            <th class="table-set">' + '客房类型编号' + '</th>\
            <th class="table-set">' + '客房大小' + '</th>\
            <th class="table-set">' + '客房状态' + '</th>\
            <th class="table-set">' + '客房图片' + '</th>\
            </tr>';
        $("thead").append(head);
        $("tbody").empty();
        $.each(data.list, function (index, ele) {
            var trData = '<tr>\
            <td><input type="radio" name="room" id="room" value='+ele.guestroomId+'></td>\
            <td>' + ele.guestroomId + '</td>\
            <td>' + ele.categoryId + '</td>\
            <td>' + ele.guestroomSize + '</td>\
            <td>' + ele.guestroomStatus + '</td>\
            <td>' + ele.guestroomPicture + '</td>\
            </tr>';
            $("tbody").append(trData);
        });
        showPageNav(data);
    })
}

function showPageNav(data){
    var $pageNav=$(".pager .clearfix");
    $pageNav.empty();
    $pageNav.append('<li>共'+data.total+'条记录</li>');
    $pageNav.append('<li><a href="javascript:showPageList('+data.prePage+');">上一页</a></li>');
    for(var i=1;i<=data.pages;i++){
        if(i==data.pageNum){
            $pageNav.append('<li>'+i+'</li>');
        }else{
            $pageNav.append('<li><a href="javascript:showPageList('+i+')">'+i+'</a></li>')
        }
    }
    $pageNav.append('<li><a href="javascript:showPageList('+data.nextPage+');">下一页</a></li>');
}

