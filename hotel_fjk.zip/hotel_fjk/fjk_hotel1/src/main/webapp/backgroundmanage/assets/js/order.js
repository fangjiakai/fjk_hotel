/**
 * Created by Administrator on 2018/3/22.
 */
$(function(){
    showPageList(1);
})

function showPageList(pageNo){
   var beginCreateTime = $("#beginCreateTime").val();
   var endCreateTime = $("#endCreateTime").val();


    $.getJSON("/order.do?beginCreateTime="+beginCreateTime+"&endCreateTime="+endCreateTime+"&pageNo="+pageNo,function(data) {
        console.log(data.list);
        $("thead").empty();
        var head = '<tr>\
            <th class="table-set">' + '订单编号' + '</th>\
            <th class="table-set">' + '顾客用户ID' + '</th>\
            <th class="table-set">' + '创建时间' + '</th>\
            <th class="table-set">' + '更新时间' + '</th>\
            <th class="table-set">' + '操作' + '</th>\
            </tr>';
        $("thead").append(head);
        $("tbody").empty();
        $.each(data.list, function (index, ele) {
                var trData = '<tr>\
            <td>' + ele.orderId + '</td>\
            <td>' + ele.userId + '</td>\
            <td>' + formatDateTime(ele.createTime) + '</td>\
            <td>' + formatDateTime(ele.updateTime) + '</td>\
            <td>\
            <div class="am-btn-toolbar">\
                <div class="am-btn-group am-btn-group-xs">\
                <button class="am-btn am-btn-default am-btn-xs am-text-secondary" onclick="showOrderDetail(' + ele.orderId + ')"><span class="am-icon-pencil-square-o"></span>查看/修改</button>\
                <button class="am-btn am-btn-default am-btn-xs am-text-danger" onclick="removeOrder(' + ele.orderId + ')"><span class="am-icon-trash-o"></span>删除</button>\
                </div>\
                </div>\
            </td>';
            $("tbody").append(trData);
        });
        showPageNav(data);
    })
    }

function showPageNav(data){
    var $pageNav=$(".pager .clearfix");
    $pageNav.empty();
    $pageNav.append('<li>共'+data.total+'条记录</li>');
    $pageNav.append('<li><a href="javascript:showPageList('+data.prePage+');">上一页</a></li>');
    for(var i=1;i<=data.pages;i++){
        if(i==data.pageNum){
            $pageNav.append('<li>'+i+'</li>');
        }else{
            $pageNav.append('<li><a href="javascript:showPageList('+i+')">'+i+'</a></li>')
        }
    }
    $pageNav.append('<li><a href="javascript:showPageList('+data.nextPage+');">下一页</a></li>');
}

function formatDateTime(inputTime) {
    var date = new Date(inputTime);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return y + '-' + m + '-' + d;
}

function showOrderDetail(orderId){
    location.href="/order/selectOrderById.do?orderId="+orderId;
}